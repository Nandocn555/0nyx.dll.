# ⚡️ Cyb3rtech Tools || [discord](https://discord.gg/mP6NvAgF2q)

![GitHub Stars](https://img.shields.io/github/stars/Cyb3rtch/Cyb3rtech-Tool?style=social) ![GitHub Forks](https://img.shields.io/github/forks/Cyb3rtch/Cyb3rtech-Tool?style=social) ![GitHub Issues](https://img.shields.io/github/issues/Cyb3rtch/Cyb3rtech-Tool)
![GitHub License](https://img.shields.io/github/license/Cyb3rtch/Cyb3rtech-Tool) ![GitHub Last Commit](https://img.shields.io/github/last-commit/Cyb3rtch/Cyb3rtech-Tool)
## > 📊 Fonctionnalités

- [x] 📍 IP Info
- [ ] 🛜 DDoS
- [ ] 🚫 Mass Report
- [x] 📞 Phone Number Lookup
- [x] 📩 Mail Info
- [x] 👤 Username Tracker
- [x] 💉 SQL Vulnerability
- [x] ☢️ Discord Raid
- [x] 👥️ Dmall
- [x] 🎭 Discord Token Info, Nuker, Bruteforce, Nitro Generator
- [ ] 🌐 Web Cloner 
      
## > 📸 Pictures

<div style="display: flex; justify-content: center;">
    <img src="https://cdn.discordapp.com/attachments/1274370571173625856/1274784761977507860/cyb3rtechtool.jpg?ex=66ce0f53&is=66ccbdd3&hm=be84c5f81d668d030d923628db2c32163ddd9c32a93c9669993a0c30dd2ef653&" alt="Screen Tool" style="width:100%; height:300px; object-fit:cover;"/>
</div>

# > ⌛️ Instalation

### > 💻 Windows

```bash
git clone https://github.com/Cyb3rtch/Cyb3rtech-Tool.git
cd Cyb3rtech-Tool
run setup.bat
run start.bat
```

### > 💻 macOS / Linux

```bash
git clone https://github.com/Cyb3rtch/Cyb3rtech-Tool.git
cd Cyb3rtech-Tool
python3 setup.py install
python3 cyb3rtech.py
```

### > 📱 Termux

```bash
pkg update
pkg install git python
git clone https://github.com/Cyb3rtch/Cyb3rtech-Tool.git
cd Cyb3rtech-Tool
python setup.py install
python cyb3rtech.py
```

## > ⛔️ Disclaimer
*🇫🇷 : Cyb3rtech Tool est destiné à une utilisation éthique et responsable. Toute utilisation illégale, malveillante ou non autorisée est strictement interdite. Les utilisateurs sont entièrement responsables de l'usage qu'ils font de cet outil. Le créateur de Cyb3rtech Tool ne pourra être tenu responsable de toute action non conforme à ces principes ou à la législation en vigueur.*

*🇺🇲 : Cyb3rtech Tool is intended for ethical and responsible use. Any illegal, malicious, or unauthorized use is strictly prohibited. Users are fully responsible for their use of this tool. The creator of Cyb3rtech Tool cannot be held liable for any actions that do not comply with these principles or applicable laws.*

## > ⚖️  Droits d'auteur
MIT License © 2024 Cyb3rtech Tool. See LICENSE file for details.
